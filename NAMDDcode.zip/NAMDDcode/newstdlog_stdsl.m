function [F,mu]=newstdlog_stdsl(x,y,R)
	
% Stability selection inspired by Meinshausen & Buehlmann, 2009
% 
% INPUTS:
%newstdlog_stdsl: means method of L1-regularized logistic regression for relationship between  gene expression and
%                      disease trait
% - x: nexp*nge design matrix 
% - y: nexp*1 variable to predict. y means disease trait
% - R: number of resampling runs (scalar or vector). In this experiment, R is scalar 
% - nexp: number of samples
% - nge: number of gene

%
% OUTPUT:
% - freq: a matrix of scores of size nge*ndisease(ndisease means number of disease traits) representing the frequency of 
%   selection of each Gene over the L steps.  
%
% code by Lin Yuan

% Rmax=max(R); if R is vector
% F=cell(length(R),1);  if R is vector
Rmax=R;
F=cell(1,1);
[n nge]=size(x);
[n ntrait]=size(y); %ntrait usually equal to one means experiment for a disease (for example Ovarian Cancer) 
halfsize= floor(n/2);
freq =zeros(nge,ntrait);
%====================================================
kfold=10;% predefine kfold parameter
%lambdamax=0.3; %predefine max lambda parameter
%radsample=randperm(n);
%teind=radsample(1:floor(n/2));
%z=stdlogMu(y(teind,:),x(teind,:),kfold,lambdamax); % get lambda parameter by cross-validation
%mu=z.lambda;
mu=0.2;
%====================================================

for i=1:Rmax
		
    % Ramdomly split the sample in two sets
	perm = randperm(n);
	i1= perm(1:halfsize);
	i2= perm((halfsize+1):n);
	
        % run the randomized logregYL on each sample and check which variables are selected
        %p=0.5;
        %ratio = sum(y == 1)/(n);
        %mu = 0.1 * 1/n * norm((1-ratio)*sum(x(y==1,:),1) + ratio*sum(x(y==-1,:),1), 'inf');
        % run the LLR on each sample and check which variables are selected
        [Y1, ~, ~, ~]=LogisticR(x(i1,:), y(i1,:), mu, [ ]);
       % [predz1, history1] = logregYL(x(i1,:), y(i1,:), mu, 100, 1.2,p);
        
        %Store
        freq(:,:)=freq(:,:) + abs(sign(Y1));
    
        % run the LLR on each sample and check which variables are selected
         [Y2, ~, ~, ~]=LogisticR(x(i2,:), y(i2,:), mu, [ ]);
        %[predz2, history2] = logregYL(x(i2,:), y(i2,:), mu, 100, 1.2,p);

        %Store
        freq(:,:)=freq(:,:) + abs(sign(Y2));
        
         if i==Rmax
            F=freq/(2*Rmax);
         end
%         for r=1:length(R)
%             if i==R(r)
%                 F{r}=freq/(2*R(r));
%             end
%          end
    
end