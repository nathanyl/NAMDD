clc;
clear;
%Here we take sample800,300methylation-30gene true associations as an
%example
% set resampling times
R=100;
% DNA methylation data
x=me8_300_30;
% Gene expression data
y=ge8_300_30;
% Calculating associations between methylation and genes using NcADMM with
% stability selection
[nncfqmg800,nnclambda800]=newstabselect_gsp(x,y,R);
%Gene expression data
x_1=ge8_300_30;
% Disease state matrix
y_1=phepn8_300_30;
% Calculating associations between genes and disease using LLR with
% stability selection
[nncfqgp800,nncmu]=newstdlog_stdsl(x_1,y_1,R);

tpr800=zeros(1000,3);
fpr800=zeros(1000,3);
pr800=zeros(1000,3);
re800=zeros(1000,3);

index=1;
% Setting different \Phi threshold
for thred=0.6:0.1:0.8
% Calculating edge (DNA methylation sites and genes) scores
nncedges_dg800=pred_networkyl(nncfqmg800,'threshold',thred);
% Calculating edge (genes and diseases) scores
nncedges_gp800=pred_networkyl(nncfqgp800,'threshold',thred);
nncedges_dg800(:,3)=nncedges_dg800(:,3)-ones(length(nncedges_dg800(:,1)),1)*0.001;
nncedges_gp800(:,3)=nncedges_gp800(:,3)-ones(length(nncedges_gp800(:,1)),1)*0.001;
[nncnetCostMatrix800,nncpairmaindex800,nncpairgaindex800]=generatematrix(nncedges_dg800,nncedges_gp800);
k_paths=2000; %varying number of paths
[nncdestination800,~]=size(nncnetCostMatrix800);
source=1;
%Finding k-shortest paths
[nncshortestPaths800, nnctotalCosts800] =kShortestPath(nncnetCostMatrix800, source,nncdestination800,k_paths);
%Calculating AUC
[nncTPR800,nncFPR800,nncAUC800]=newCalcuNNCAUC(nncshortestPaths800,nnctotalCosts800,nncpairmaindex800);

tpr800(:,index)=nncTPR800;
fpr800(:,index)=nncFPR800;

index=index+1;
eval(['AUC800',num2str(thred*10),'=',num2str(nncAUC800),';']);

end

