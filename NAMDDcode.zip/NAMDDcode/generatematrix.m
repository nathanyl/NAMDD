
function [netCostMatrix,pairmaindex,pairgaindex]=generatematrix(edges_dg,edges_gp)
%From edges_dg and
%edges_gp generate association matrix�� run k shortest paths
[n1,p1]=size(edges_dg); % get size of methylation-gene association matrix
[n2,p2]=size(edges_gp); % get size of gene-disease association matrix
x=edges_dg;
y=edges_gp;
genelength=length(intersect(unique(x(:,2)),unique(y(:,1))));
N=1+length(unique(x(:,1)))+length(unique(x(:,2)))+1;% including auxiliary start point, auxiliary end point,DNA methylation sites, genes
netCostMatrix=zeros(N+1,N+1); 
pairmaindex=zeros(length(unique(x(:,1))),2); 
pairmaindex(:,1)=[2:(length(unique(x(:,1)))+1)];
tempa=unique(x(:,1)); 
pairmaindex(:,2)=tempa;
pairgaindex=zeros(length(unique(x(:,2))),2);
pairgaindex(:,1)=[(length(unique(x(:,1)))+2):(length(unique(x(:,1)))+1+length(unique(x(:,2))))];
tempb=unique(x(:,2));
pairgaindex(:,2)=tempb;
netCostMatrix(1,2:(length(unique(x(:,1)))+1))=1;
edges_dg(:,3)=-log(edges_dg(:,3)); %change to -log score for calculate minimal value
edges_gp(:,3)=-log(edges_gp(:,3)); %change to -log score for calculate minimal value
for i=1:n1
    indexm=edges_dg(i,1);  %The location of methylation sites in the methylation matrix
    indexg=edges_dg(i,2);   %Gene's position in the gene matrix
    for j=1:length(unique(x(:,1)))
        if indexm==pairmaindex(j,2)
            mnetindex=pairmaindex(j,1);  %Find the location of the methylation site in the correlation matrix by pairmaindex
        end
    end
    for z=1:length(unique(x(:,2)))
        if indexg==pairgaindex(z,2)
            gnetindex=pairgaindex(z,1);  %Find the location of the gene in the correlation matrix by pairgaindex
        end
    end
    netCostMatrix(mnetindex,gnetindex)=edges_dg(i,3);
end
for i=1:n2
    indexg=edges_gp(i,1);
    if sum(ismember(edges_dg(:,2),indexg))>0
        for j=1:length(unique(x(:,2)))
        if indexg==pairgaindex(j,2)
            gnetindex=pairgaindex(j,1);  %Finding the location of gene in the adjacency matrix by pairgaindex
        end
        end
    netCostMatrix(gnetindex,N)=edges_gp(i,3);
    end
end
    netCostMatrix(N,N+1)=1;
    netCostMatrix(netCostMatrix==0)=inf;
    netCostMatrix(logical(eye(N+1)))=0;
    
    
    


        
    
    



