function [TPR,FPR,AUC]=newCalcuNNCAUC(shortestpath,totalcosts,maindex)
tp=shortestpath;
tco=totalcosts;
n=length(tp);
inid=zeros(n,2);
for i=1:n
    networkid=tp{i}(2);
    midindex=find(maindex(:,1)==networkid);
    finid=maindex(midindex,2);
    inid(i,1)=finid;
    inid(i,2)=1/tco(i);
end
unid=unique(inid(:,1));
unisize=length(unid);
finprd=zeros(unisize,2);
for i=1:unisize
    finprd(i,1)=unid(i);
    mulid=(find(inid(:,1)==unid(i)));
    finprd(i,2)=sum(inid(mulid,2))/length(mulid);
end
nncpre=zeros(1000,1);% initialize predictor
for i=1:length(finprd(:,1))
    nncpre(finprd(i,1))=finprd(i,2);
end
truid=[ones(300,1);zeros(700,1)];
[TPR, FPR, AUC]=roc_curve(nncpre, truid);
end