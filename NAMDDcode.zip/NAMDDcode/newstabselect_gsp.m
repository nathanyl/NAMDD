function [F,lambda]=newstabselect_gsp(x,y,R)
	
% Stability selection inspired by Meinshausen & Buehlmann, 2009
% 
% INPUTS:
%newstabselect_gsp: gsp means method for  group sparse of DNA methylation and
%gene  expression
% - x: nexp*ndm design matrix
% - y: nexp*nge variable to predict
% - R: number of resampling runs (scalar or vector) in this experiment,R is
%       scalar
% - nexp:number of samples
% - ndm: number of DNA methylation
% - nge: number of genes

% - L: number of method steps to run
%
% OUTPUT:
% - freq: a matrix of scores of size ndm*nge representing the frequency of 
%   selection of each DNA methylation site over the L steps.  
%
%  code by Lin Yuan

	
% Rmax=max(R); if R is vector
%F=cell(length(R),1); if R is vector
Rmax=R; % - R: number of resampling runs (scalar or vector) in this experiment,R is scalar
F=cell(1,1);
[nexp p]=size(x); %get size of x: DNA methylation matrix
ndm=p;
[nexp q]=size(y); %get size of y: Gene expression matrix 
nge=q;
halfsize= floor(nexp/2);
freq =zeros(ndm,nge);
%====================================================
kfold=10;% predefine kfold parameter
%radsample=randperm(nexp);
%teind=radsample(1:floor(nexp/2));
%z=estimateLambda(y(teind,:),x(teind,:),kfold,lambdamax); % get lambda parameter by cross-validation
lambda = 1; %pre-define lambda
%====================================================

for i=1:Rmax
		
    % Ramdomly split the sample in two sets
	perm = randperm(nexp);
	i1= perm(1:halfsize);
	i2= perm((halfsize+1):nexp);
	
    % run the randomized ncspadmm(Non-Convex SParse ADMM) on each sample and check which variables are selected
       
       mu = 5;
       opt = [];
       opt.Verbose = 1;
       opt.rho = 500;
       opt.RelStopTol = 1e-6;
 
        % Run ncspadmm in fixed-steps setting
        [Xnc1, optinfnc1] = ncspadmm(x(i1,:), y(i1,:), lambda,mu,opt,0.5,0.5); % ncspadmm(Non-Convex SParse ADMM)
        
        %Store
        freq(:,:)=freq(:,:) + abs(sign(Xnc1));
    
        % Run ncspadmm in fixed-steps setting
        [Xnc2, optinfnc2] = ncspadmm(x(i2,:), y(i2,:), lambda,mu,opt,0.5,0.5); % ncspadmm(Non-Convex SParse ADMM)

        %Store
        freq(:,:)=freq(:,:) + abs(sign(Xnc2));
        
        if i==Rmax
           F=freq/(2*Rmax);
        end
%     for r=1:length(R)
%         if i==R(r)
%             F{r}=freq/(2*R(r));
%         end
%     end
    
end