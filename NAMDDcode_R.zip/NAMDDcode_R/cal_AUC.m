function [TPR,FPR,AUC]=cal_AUC(kpath)
[m,n]=size(kpath);
uniid=unique(kpath(:,1));
idleg=length(uniid);
nncpre=zeros(1000,1);
for i=1:idleg
    temp=find(uniid(i)==kpath(:,1));
    nncpre(uniid(i),1)=mean(kpath(temp,7));
end

truid=[ones(300,1);zeros(700,1)];
[TPR, FPR, AUC]=roc_curve(nncpre, truid);
end