function [wholepath, kpath]=findkpath(dme_ge_assinf,ge_phe_assinf,K)
%%dme_ge_assinf is a n1*3 matrix first column is dme id,second column is
%%gene id, third column  is ass score
%%ge_phe_assinf is a n2*3 ,atrix first column is geme, second column is phenotype, third column is ass score
%% first find gene which in both dme_ge_assinf and ge_phe_assinf
x=dme_ge_assinf; y=ge_phe_assinf;
temp1=unique(x(:,2)); genum_dg=length(temp1);
temp2=unique(y(:,1)); genum_gp=length(temp2);

matchgeid=zeros(min(genum_dg,genum_gp),1);
index=1;
for i=1:genum_dg
    for j=1:genum_gp
        if temp1(i)==temp2(j)
            matchgeid(index)=temp1(i);
            index=index+1;
        end
    end
end

temp3=index-1;
pathinf=zeros(temp3,7);
idori=1;
for i=1:temp3
    idge=matchgeid(i);
    tempindex=find(x(:,2)==idge);
    yindex=find(y(:,1)==idge);
    leg=length(tempindex);
    pathinf(idori:(idori+leg-1),1:3)=x(tempindex,:);
    pathinf(idori:(idori+leg-1),4:6)=repmat(y(yindex,:),leg,1);
    pathinf(idori:(idori+leg-1),7)=x(tempindex,3)+y(yindex,3);
    idori=idori+leg;
end

    [~,I]=sort(pathinf(:,7),'descend');
    wholepath=pathinf(I,:);
    if length(wholepath(:,1))<K
        kpath=wholepath;
    else
        kpath=wholepath(1:K,:);
    end
end
    
    
    
    
    
    
    
    
